nesasm is the assembler and ppmckc is the Music Markup Language preprocessor. In bin/ there is the Windows version and precompiled OSX and Linux binaries that may or may not work for you. The src/ compiles easily on both OSs. 

The asm sound drivers have been heavily modified from ppmck vanilla to be MMC1 compatible. YOU MUST COMPILE THE MML WITH NESLYRICS' COPY OF THE SOUND DRIVER. This only precludes you from using Namco extensions. 


You compile a music markup file by going to tools/songs and "./mknsf mysong" 

You compile the ROM with "tools/nesasm neslyric.asm"

Easy as apple pie!

PS. I am not aware of a good open source editor for NES graphics, but I use the freeware YY-CHR, which runs just fine under Linux Wine but is borked on OSX Wine.