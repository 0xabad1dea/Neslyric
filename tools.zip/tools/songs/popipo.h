; Title: "Po Pi Po (Vocaloid)"
; Composer: "2008 niconico/sm5508956"
; Maker: "2011 0xabad1dea"

	.bank	0
	.if TOTAL_SONGS > 1
song_addr_table:
	dw	song_000_track_table
	.if (ALLOW_BANK_SWITCH)
song_bank_table:
	dw	song_000_bank_table
	.endif ; ALLOW_BANK_SWITCH
	.endif ; TOTAL_SONGS > 1
song_000_track_table:
	dw	song_000_00
	dw	song_000_01
	dw	song_000_02
	dw	song_000_03
	dw	song_000_04
	.if (ALLOW_BANK_SWITCH)
song_000_bank_table:
	db	bank(song_000_00)*2
	db	bank(song_000_01)*2
	db	bank(song_000_02)*2
	db	bank(song_000_03)*2
	db	bank(song_000_04)*2
	.endif

song_000_00:	;Trk A
	db	$fe,$82,$fd,$8b,$f8,$04,$fb,$ff	;Trk A; popipo.mml: 62
	db	$30,$0d,$27,$06,$30,$0d,$27,$07	;Trk A; popipo.mml: 65
	db	$30,$0c,$32,$0d,$37,$0d,$fb,$03	;Trk A; popipo.mml: 65
	db	$32,$1a,$fb,$ff,$30,$0d,$27,$06	;Trk A; popipo.mml: 65
	db	$30,$0d,$27,$06,$30,$0d,$32,$0d	;Trk A; popipo.mml: 65
	db	$37,$0d,$fb,$03,$32,$1a,$fb,$ff	;Trk A; popipo.mml: 65
	db	$fe,$06,$fe,$06,$fd,$02,$10,$0d	;Trk A; popipo.mml: 65
	db	$0b,$06,$10,$0d,$0b,$06,$10,$0d	;Trk A; popipo.mml: 66
	db	$12,$0d,$17,$0d,$12,$1a,$10,$0c	;Trk A; popipo.mml: 66
	db	$0b,$07,$10,$0d,$0b,$06,$10,$0d	;Trk A; popipo.mml: 66
	db	$12,$0d,$17,$0d,$12,$19,$10,$0d	;Trk A; popipo.mml: 66
	db	$0b,$07,$10,$0d,$0b,$06,$10,$0d	;Trk A; popipo.mml: 68
	db	$12,$0d,$17,$0d,$12,$19,$10,$0d	;Trk A; popipo.mml: 68
	db	$0b,$07,$10,$0c,$0b,$07,$10,$0d	;Trk A; popipo.mml: 68
	db	$12,$0d,$17,$0c,$12,$1a,$fd,$01	;Trk A; popipo.mml: 68
	db	$10,$0d,$10,$0d,$10,$0d,$10,$0d	;Trk A; popipo.mml: 69
	db	$0b,$06,$09,$0d,$04,$13,$12,$0d	;Trk A; popipo.mml: 69
	db	$10,$0d,$10,$0d,$10,$0d,$10,$0c	;Trk A; popipo.mml: 70
	db	$0b,$07,$10,$0d,$12,$13,$14,$0d	;Trk A; popipo.mml: 70
	db	$fd,$02,$10,$0d,$10,$0d,$10,$0c	;Trk A; popipo.mml: 71
	db	$10,$0d,$0b,$07,$09,$0d,$04,$13	;Trk A; popipo.mml: 71
	db	$12,$0d,$10,$0d,$10,$0c,$10,$0d	;Trk A; popipo.mml: 71
	db	$10,$0d,$0b,$07,$10,$0c,$12,$14	;Trk A; popipo.mml: 72
	db	$14,$0d,$fe,$05,$14,$0c,$10,$07	;Trk A; popipo.mml: 72
	db	$14,$06,$fc,$07,$14,$06,$14,$07	;Trk A; popipo.mml: 75
	db	$15,$06,$17,$06,$19,$07,$17,$06	;Trk A; popipo.mml: 75
	db	$17,$07,$fc,$0d,$15,$0c,$14,$0d	;Trk A; popipo.mml: 75
	db	$15,$0d,$14,$0d,$15,$0d,$14,$1a	;Trk A; popipo.mml: 75
	db	$fc,$19,$14,$0d,$10,$07,$14,$06	;Trk A; popipo.mml: 75
	db	$fc,$06,$14,$07,$14,$06,$15,$07	;Trk A; popipo.mml: 77
	db	$17,$06,$19,$07,$17,$06,$17,$06	;Trk A; popipo.mml: 77
	db	$fc,$0d,$15,$0d,$14,$0d,$15,$0d	;Trk A; popipo.mml: 77
	db	$14,$0d,$10,$26,$fc,$1a,$14,$0d	;Trk A; popipo.mml: 77
	db	$10,$06,$14,$07,$fc,$06,$14,$07	;Trk A; popipo.mml: 79
	db	$14,$06,$15,$06,$17,$07,$19,$06	;Trk A; popipo.mml: 79
	db	$17,$07,$17,$06,$fc,$0d,$15,$0d	;Trk A; popipo.mml: 79
	db	$14,$0d,$15,$0d,$14,$0c,$15,$0d	;Trk A; popipo.mml: 79
	db	$14,$1a,$fc,$1a,$14,$0d,$14,$0c	;Trk A; popipo.mml: 79
	db	$14,$0d,$15,$0d,$17,$0d,$20,$0d	;Trk A; popipo.mml: 81
	db	$1b,$0d,$20,$40,$20,$0d,$20,$0d	;Trk A; popipo.mml: 81
	db	$20,$06,$20,$07,$20,$06,$20,$06	;Trk A; popipo.mml: 81
	db	$fd,$01,$20,$0d,$20,$0d,$20,$0d	;Trk A; popipo.mml: 83
	db	$20,$0d,$1b,$06,$19,$0d,$14,$13	;Trk A; popipo.mml: 83
	db	$22,$0d,$20,$0d,$20,$0d,$20,$0d	;Trk A; popipo.mml: 83
	db	$20,$0d,$1b,$06,$20,$0d,$22,$13	;Trk A; popipo.mml: 84
	db	$24,$0d,$fd,$02,$20,$0d,$20,$0d	;Trk A; popipo.mml: 84
	db	$20,$0d,$20,$0d,$1b,$06,$19,$0d	;Trk A; popipo.mml: 85
	db	$14,$13,$22,$0d,$20,$0d,$20,$0d	;Trk A; popipo.mml: 85
	db	$20,$0d,$20,$0c,$1b,$07,$20,$0d	;Trk A; popipo.mml: 86
	db	$22,$13,$24,$0d,$34,$1a,$30,$19	;Trk A; popipo.mml: 86
	db	$32,$0d,$37,$0d,$fc,$0d,$35,$0d	;Trk A; popipo.mml: 89
	db	$34,$0d,$35,$0c,$34,$0d,$35,$0d	;Trk A; popipo.mml: 89
	db	$34,$1a,$fc,$1a,$34,$19,$30,$1a	;Trk A; popipo.mml: 89
	db	$32,$0d,$37,$0d,$fc,$0d,$35,$0c	;Trk A; popipo.mml: 91
	db	$34,$0d,$35,$0d,$34,$0d,$35,$0d	;Trk A; popipo.mml: 91
	db	$34,$1a,$fc,$19,$30,$1a,$40,$1a	;Trk A; popipo.mml: 91
	db	$3b,$0d,$37,$19,$35,$0d,$34,$0d	;Trk A; popipo.mml: 93
	db	$35,$0d,$34,$0d,$35,$0d,$37,$19	;Trk A; popipo.mml: 93
	db	$30,$1a,$fc,$1a,$34,$0d,$35,$0c	;Trk A; popipo.mml: 93
	db	$37,$0d,$40,$0d,$3b,$1a,$40,$33	;Trk A; popipo.mml: 95
	db	$fb,$02,$fd,$02,$f8,$05,$34,$34	;Trk A; popipo.mml: 95
	db	$f8,$ff,$fb,$ff,$fe,$06,$fd,$01	;Trk A; popipo.mml: 95
	db	$30,$0d,$27,$06,$30,$0d,$27,$06	;Trk A; popipo.mml: 97
	db	$30,$0d,$32,$0d,$37,$0d,$fb,$03	;Trk A; popipo.mml: 97
	db	$32,$1a,$fb,$ff,$30,$0c,$27,$07	;Trk A; popipo.mml: 97
	db	$30,$0d,$27,$06,$30,$0d,$32,$0d	;Trk A; popipo.mml: 97
	db	$37,$0d,$fb,$03,$32,$19,$fb,$ff	;Trk A; popipo.mml: 97
	db	$34,$1a,$40,$1a,$42,$0d,$40,$0d	;Trk A; popipo.mml: 99
	db	$3b,$0c,$37,$0d,$fb,$03,$40,$0d	;Trk A; popipo.mml: 99
	db	$40,$07,$40,$06,$fc,$06,$40,$07	;Trk A; popipo.mml: 99
	db	$40,$0d,$40,$0d,$40,$0c,$40,$07	;Trk A; popipo.mml: 99
	db	$40,$06,$40,$0d,$fb,$ff,$fe,$80	;Trk A; popipo.mml: 99
	db	$20,$0d,$17,$06,$20,$0d,$17,$07	;Trk A; popipo.mml: 101
	db	$20,$0d,$22,$0c,$27,$0d,$fb,$03	;Trk A; popipo.mml: 101
	db	$22,$1a,$fb,$ff,$20,$0d,$17,$06	;Trk A; popipo.mml: 101
	db	$20,$0d,$17,$07,$20,$0c,$22,$0d	;Trk A; popipo.mml: 101
	db	$27,$0d,$fb,$03,$22,$1a,$fb,$ff	;Trk A; popipo.mml: 101
	db	$24,$1a,$30,$19,$32,$0d,$30,$0d	;Trk A; popipo.mml: 103
	db	$2b,$0d,$27,$0d,$fb,$03,$30,$0d	;Trk A; popipo.mml: 103
	db	$30,$06,$30,$06,$fc,$07,$30,$06	;Trk A; popipo.mml: 103
	db	$30,$0d,$30,$0d,$30,$0d,$30,$06	;Trk A; popipo.mml: 103
	db	$30,$07,$30,$0d,$fb,$ff,$30,$0c	;Trk A; popipo.mml: 103
	db	$27,$07,$30,$0d,$27,$06,$30,$0d	;Trk A; popipo.mml: 104
	db	$32,$0d,$37,$0d,$fb,$03,$32,$19	;Trk A; popipo.mml: 104
	db	$fb,$ff,$30,$0d,$27,$07,$30,$0d	;Trk A; popipo.mml: 104
	db	$27,$06,$30,$0d,$32,$0d,$37,$0d	;Trk A; popipo.mml: 104
	db	$fb,$03,$32,$19,$fb,$ff,$24,$1a	;Trk A; popipo.mml: 104
	db	$30,$1a,$32,$0d,$30,$0c,$2b,$0d	;Trk A; popipo.mml: 106
	db	$27,$0d,$fb,$03,$30,$0d,$30,$06	;Trk A; popipo.mml: 106
	db	$30,$07,$fc,$06,$30,$07,$30,$0d	;Trk A; popipo.mml: 106
	db	$30,$0c,$30,$0d,$30,$07,$30,$06	;Trk A; popipo.mml: 106
	db	$30,$0d,$fb,$ff,$fd,$88,$fe,$06	;Trk A; popipo.mml: 106
	db	$30,$0d,$27,$06,$30,$0d,$27,$07	;Trk A; popipo.mml: 109
	db	$30,$0c,$32,$0d,$37,$0d,$32,$1a	;Trk A; popipo.mml: 109
	db	$30,$0d,$27,$06,$30,$0d,$27,$06	;Trk A; popipo.mml: 109
	db	$30,$0d,$32,$0d,$37,$0d,$32,$1a	;Trk A; popipo.mml: 109
	db	$30,$19,$32,$1a,$34,$1a,$35,$1a	;Trk A; popipo.mml: 110
	db	$37,$0c,$35,$07,$34,$26,$32,$0d	;Trk A; popipo.mml: 110
	db	$30,$07,$2b,$13,$32,$0d,$30,$67	;Trk A; popipo.mml: 110

song_000_00_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_00_lp)*2
	dw	song_000_00_lp


song_000_01:	;Trk B
	db	$fe,$05,$fd,$07,$fc,$67,$fc,$67	;Trk B; popipo.mml: 113
	db	$29,$0d,$27,$0c,$25,$07,$25,$06	;Trk B; popipo.mml: 115
	db	$27,$0d,$30,$0d,$2b,$0d,$29,$06	;Trk B; popipo.mml: 115
	db	$29,$07,$2b,$0d,$29,$0c,$27,$0d	;Trk B; popipo.mml: 115
	db	$25,$07,$25,$06,$27,$0d,$30,$0d	;Trk B; popipo.mml: 115
	db	$2b,$0d,$29,$06,$29,$07,$2b,$0c	;Trk B; popipo.mml: 115
	db	$29,$0d,$27,$0d,$25,$07,$25,$06	;Trk B; popipo.mml: 116
	db	$27,$0d,$30,$0d,$2b,$0d,$29,$06	;Trk B; popipo.mml: 116
	db	$29,$06,$2b,$0d,$29,$0d,$27,$0d	;Trk B; popipo.mml: 116
	db	$25,$06,$25,$07,$27,$0d,$32,$0d	;Trk B; popipo.mml: 116
	db	$30,$0c,$2b,$07,$2b,$06,$30,$0d	;Trk B; popipo.mml: 116
	db	$fd,$02,$30,$0d,$30,$0d,$30,$0d	;Trk B; popipo.mml: 118
	db	$30,$0d,$2b,$06,$29,$0d,$24,$13	;Trk B; popipo.mml: 118
	db	$32,$0d,$30,$0d,$30,$0d,$30,$0d	;Trk B; popipo.mml: 118
	db	$30,$0c,$2b,$07,$30,$0d,$32,$13	;Trk B; popipo.mml: 119
	db	$34,$0d,$fd,$01,$30,$0d,$30,$0d	;Trk B; popipo.mml: 119
	db	$30,$0c,$30,$0d,$2b,$07,$29,$0d	;Trk B; popipo.mml: 120
	db	$24,$13,$32,$0d,$30,$0d,$30,$0c	;Trk B; popipo.mml: 120
	db	$30,$0d,$30,$0d,$2b,$07,$30,$0c	;Trk B; popipo.mml: 121
	db	$32,$14,$34,$0d,$fe,$06,$34,$0c	;Trk B; popipo.mml: 121
	db	$30,$07,$37,$06,$fc,$07,$34,$06	;Trk B; popipo.mml: 123
	db	$34,$07,$35,$06,$37,$06,$39,$07	;Trk B; popipo.mml: 123
	db	$37,$06,$37,$07,$fc,$0d,$35,$0c	;Trk B; popipo.mml: 123
	db	$34,$0d,$35,$0d,$34,$0d,$35,$0d	;Trk B; popipo.mml: 123
	db	$34,$1a,$fc,$19,$34,$0d,$30,$07	;Trk B; popipo.mml: 123
	db	$34,$06,$fc,$06,$34,$07,$34,$06	;Trk B; popipo.mml: 124
	db	$35,$07,$37,$06,$39,$07,$37,$06	;Trk B; popipo.mml: 124
	db	$37,$06,$fc,$0d,$35,$0d,$34,$0d	;Trk B; popipo.mml: 124
	db	$35,$0d,$34,$0d,$30,$26,$fc,$1a	;Trk B; popipo.mml: 124
	db	$34,$0d,$30,$06,$34,$07,$fc,$06	;Trk B; popipo.mml: 125
	db	$34,$07,$34,$06,$35,$06,$37,$07	;Trk B; popipo.mml: 125
	db	$39,$06,$37,$07,$37,$06,$fc,$0d	;Trk B; popipo.mml: 125
	db	$35,$0d,$34,$0d,$35,$0d,$34,$0c	;Trk B; popipo.mml: 125
	db	$35,$0d,$34,$1a,$fc,$1a,$34,$0d	;Trk B; popipo.mml: 125
	db	$34,$0c,$34,$0d,$35,$0d,$37,$0d	;Trk B; popipo.mml: 126
	db	$40,$0d,$3b,$0d,$fb,$00,$40,$40	;Trk B; popipo.mml: 126
	db	$40,$0d,$40,$0d,$40,$06,$40,$07	;Trk B; popipo.mml: 126
	db	$40,$06,$40,$06,$fd,$02,$30,$0d	;Trk B; popipo.mml: 126
	db	$30,$0d,$30,$0d,$30,$0d,$2b,$06	;Trk B; popipo.mml: 128
	db	$29,$0d,$24,$13,$32,$0d,$30,$0d	;Trk B; popipo.mml: 128
	db	$30,$0d,$30,$0d,$30,$0d,$2b,$06	;Trk B; popipo.mml: 129
	db	$30,$0d,$32,$13,$34,$0d,$fd,$01	;Trk B; popipo.mml: 129
	db	$30,$0d,$30,$0d,$30,$0d,$30,$0d	;Trk B; popipo.mml: 130
	db	$2b,$06,$29,$0d,$24,$13,$32,$0d	;Trk B; popipo.mml: 130
	db	$30,$0d,$30,$0d,$30,$0d,$30,$0c	;Trk B; popipo.mml: 131
	db	$2b,$07,$30,$0d,$32,$13,$34,$0d	;Trk B; popipo.mml: 131
	db	$34,$1a,$30,$19,$32,$0d,$37,$0d	;Trk B; popipo.mml: 133
	db	$fc,$0d,$35,$0d,$34,$0d,$35,$0c	;Trk B; popipo.mml: 133
	db	$34,$0d,$35,$0d,$34,$1a,$fc,$1a	;Trk B; popipo.mml: 133
	db	$34,$19,$30,$1a,$32,$0d,$37,$0d	;Trk B; popipo.mml: 134
	db	$fc,$0d,$35,$0c,$34,$0d,$35,$0d	;Trk B; popipo.mml: 134
	db	$34,$0d,$35,$0d,$34,$1a,$fc,$19	;Trk B; popipo.mml: 134
	db	$30,$1a,$40,$1a,$3b,$0d,$37,$19	;Trk B; popipo.mml: 135
	db	$35,$0d,$34,$0d,$35,$0d,$34,$0d	;Trk B; popipo.mml: 135
	db	$35,$0d,$37,$19,$30,$1a,$fc,$1a	;Trk B; popipo.mml: 135
	db	$34,$0d,$35,$0c,$37,$0d,$40,$0d	;Trk B; popipo.mml: 136
	db	$3b,$1a,$40,$33,$fb,$02,$f8,$03	;Trk B; popipo.mml: 136
	db	$32,$34,$f8,$ff,$fb,$ff,$fe,$82	;Trk B; popipo.mml: 136
	db	$fd,$02,$40,$0d,$37,$06,$40,$0d	;Trk B; popipo.mml: 137
	db	$37,$06,$40,$0d,$42,$0d,$47,$0d	;Trk B; popipo.mml: 138
	db	$fb,$03,$42,$1a,$fb,$ff,$40,$0c	;Trk B; popipo.mml: 138
	db	$37,$07,$40,$0d,$37,$06,$40,$0d	;Trk B; popipo.mml: 138
	db	$42,$0d,$47,$0d,$fb,$03,$42,$19	;Trk B; popipo.mml: 138
	db	$fb,$ff,$14,$1a,$20,$1a,$22,$0d	;Trk B; popipo.mml: 138
	db	$20,$0d,$1b,$0c,$17,$0d,$fb,$03	;Trk B; popipo.mml: 139
	db	$20,$0d,$20,$07,$20,$06,$fc,$06	;Trk B; popipo.mml: 139
	db	$20,$07,$20,$0d,$20,$0d,$20,$0c	;Trk B; popipo.mml: 139
	db	$20,$07,$20,$06,$20,$0d,$fb,$ff	;Trk B; popipo.mml: 139
	db	$fe,$81,$fd,$01,$30,$0d,$27,$06	;Trk B; popipo.mml: 140
	db	$30,$0d,$27,$07,$30,$0d,$32,$0c	;Trk B; popipo.mml: 141
	db	$37,$0d,$fb,$03,$32,$1a,$fb,$ff	;Trk B; popipo.mml: 141
	db	$30,$0d,$27,$06,$30,$0d,$27,$07	;Trk B; popipo.mml: 141
	db	$30,$0c,$32,$0d,$37,$0d,$fb,$03	;Trk B; popipo.mml: 141
	db	$32,$1a,$fb,$ff,$24,$1a,$30,$19	;Trk B; popipo.mml: 141
	db	$32,$0d,$30,$0d,$2b,$0d,$27,$0d	;Trk B; popipo.mml: 142
	db	$fb,$03,$30,$0d,$30,$06,$30,$06	;Trk B; popipo.mml: 142
	db	$fc,$07,$30,$06,$30,$0d,$30,$0d	;Trk B; popipo.mml: 142
	db	$30,$0d,$30,$06,$30,$07,$30,$06	;Trk B; popipo.mml: 142
	db	$fc,$07,$fb,$ff,$40,$0c,$37,$07	;Trk B; popipo.mml: 142
	db	$40,$0d,$37,$06,$40,$0d,$42,$0d	;Trk B; popipo.mml: 144
	db	$47,$0d,$fb,$03,$42,$19,$fb,$ff	;Trk B; popipo.mml: 144
	db	$40,$0d,$37,$07,$40,$0d,$37,$06	;Trk B; popipo.mml: 144
	db	$40,$0d,$42,$0d,$47,$0d,$fb,$03	;Trk B; popipo.mml: 144
	db	$42,$19,$fb,$ff,$24,$1a,$30,$1a	;Trk B; popipo.mml: 144
	db	$32,$0d,$30,$0c,$2b,$0d,$27,$0d	;Trk B; popipo.mml: 145
	db	$fb,$03,$30,$0d,$30,$06,$30,$07	;Trk B; popipo.mml: 145
	db	$fc,$06,$30,$07,$30,$0d,$30,$0c	;Trk B; popipo.mml: 145
	db	$30,$0d,$30,$07,$30,$06,$30,$07	;Trk B; popipo.mml: 145
	db	$fc,$06,$fb,$ff,$fd,$88,$fe,$82	;Trk B; popipo.mml: 145
	db	$40,$0d,$37,$06,$40,$0d,$37,$07	;Trk B; popipo.mml: 147
	db	$40,$0c,$42,$0d,$47,$0d,$42,$1a	;Trk B; popipo.mml: 147
	db	$40,$0d,$37,$06,$40,$0d,$37,$06	;Trk B; popipo.mml: 147
	db	$40,$0d,$42,$0d,$47,$0d,$42,$1a	;Trk B; popipo.mml: 147
	db	$40,$19,$42,$1a,$44,$1a,$45,$1a	;Trk B; popipo.mml: 148
	db	$47,$0c,$45,$07,$44,$26,$42,$0d	;Trk B; popipo.mml: 148
	db	$40,$07,$3b,$13,$42,$0d,$40,$67	;Trk B; popipo.mml: 148

song_000_01_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_01_lp)*2
	dw	song_000_01_lp


song_000_02:	;Trk C
	db	$fe,$8f,$f8,$04,$fb,$03,$40,$06	;Trk C; popipo.mml: 59
	db	$fc,$07,$37,$03,$fc,$03,$40,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$37,$03,$fc,$04,$40,$06	;Trk C; popipo.mml: 153
	db	$fc,$06,$42,$06,$fc,$07,$47,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$42,$0d,$fc,$0d,$40,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$37,$03,$fc,$03,$40,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$37,$03,$fc,$03,$40,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$42,$06,$fc,$07,$47,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$42,$0d,$fc,$0d,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$03,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$03,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$06,$fc,$07,$37,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$0d,$fc,$0d,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$06,$27,$03,$fc,$04,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$03,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$06,$fc,$07,$37,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$0c,$fc,$0d,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$04,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$03,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$06,$fc,$07,$37,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$32,$0c,$fc,$0d,$30,$06	;Trk C; popipo.mml: 153
	db	$fc,$07,$27,$03,$fc,$04,$37,$06	;Trk C; popipo.mml: 154
	db	$fc,$06,$2b,$03,$fc,$04,$30,$06	;Trk C; popipo.mml: 154
	db	$fc,$07,$32,$06,$fc,$07,$37,$06	;Trk C; popipo.mml: 154
	db	$fc,$06,$fc,$1a,$f8,$07,$fb,$01	;Trk C; popipo.mml: 154
	db	$70,$ce,$f8,$ff,$10,$13,$fc,$07	;Trk C; popipo.mml: 155
	db	$10,$12,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 155
	db	$14,$13,$fc,$07,$19,$12,$fc,$07	;Trk C; popipo.mml: 155
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 156
	db	$17,$13,$fc,$07,$10,$12,$fc,$07	;Trk C; popipo.mml: 156
	db	$10,$13,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$14,$12,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$17,$12,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$10,$13,$fc,$07,$14,$12,$fc,$07	;Trk C; popipo.mml: 158
	db	$14,$13,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$19,$13,$fc,$07,$15,$12,$fc,$07	;Trk C; popipo.mml: 158
	db	$17,$13,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$10,$12,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$14,$13,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$19,$12,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$17,$13,$fc,$07,$10,$12,$fc,$07	;Trk C; popipo.mml: 158
	db	$10,$13,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$14,$13,$fc,$07,$19,$12,$fc,$07	;Trk C; popipo.mml: 158
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 158
	db	$17,$12,$fc,$07,$19,$09,$fc,$04	;Trk C; popipo.mml: 158
	db	$17,$09,$fc,$04,$15,$05,$fc,$02	;Trk C; popipo.mml: 160
	db	$15,$04,$fc,$02,$17,$09,$fc,$04	;Trk C; popipo.mml: 160
	db	$f8,$06,$40,$13,$fc,$07,$40,$12	;Trk C; popipo.mml: 160
	db	$fc,$07,$f8,$ff,$19,$09,$fc,$04	;Trk C; popipo.mml: 160
	db	$17,$09,$fc,$04,$15,$04,$fc,$02	;Trk C; popipo.mml: 160
	db	$15,$05,$fc,$02,$17,$09,$fc,$04	;Trk C; popipo.mml: 160
	db	$f8,$05,$42,$09,$fc,$04,$45,$09	;Trk C; popipo.mml: 160
	db	$fc,$03,$42,$09,$fc,$04,$45,$09	;Trk C; popipo.mml: 160
	db	$fc,$04,$f8,$ff,$19,$09,$fc,$04	;Trk C; popipo.mml: 160
	db	$17,$09,$fc,$04,$15,$04,$fc,$02	;Trk C; popipo.mml: 161
	db	$15,$05,$fc,$02,$17,$09,$fc,$04	;Trk C; popipo.mml: 161
	db	$f8,$06,$40,$12,$fc,$07,$40,$13	;Trk C; popipo.mml: 161
	db	$fc,$07,$f8,$ff,$19,$09,$fc,$04	;Trk C; popipo.mml: 161
	db	$17,$09,$fc,$04,$15,$04,$fc,$02	;Trk C; popipo.mml: 161
	db	$15,$05,$fc,$02,$17,$09,$fc,$03	;Trk C; popipo.mml: 161
	db	$f8,$05,$42,$09,$fc,$04,$45,$09	;Trk C; popipo.mml: 161
	db	$fc,$04,$42,$09,$fc,$04,$45,$09	;Trk C; popipo.mml: 161
	db	$fc,$04,$f8,$ff,$10,$13,$fc,$07	;Trk C; popipo.mml: 161
	db	$10,$12,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$13,$fc,$07,$19,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$13,$fc,$07,$10,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$13,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$12,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$12,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$13,$fc,$07,$14,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$13,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$13,$fc,$07,$15,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$13,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$12,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$13,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$12,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$13,$fc,$07,$10,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$13,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$13,$fc,$07,$19,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$13,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$12,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$13,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$12,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$13,$fc,$07,$15,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$13,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$13,$fc,$07,$14,$12,$fc,$07	;Trk C; popipo.mml: 163
	db	$14,$13,$fc,$07,$19,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$19,$12,$fc,$07,$15,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$17,$13,$fc,$07,$10,$13,$fc,$07	;Trk C; popipo.mml: 163
	db	$10,$12,$fc,$07,$14,$13,$fc,$07	;Trk C; popipo.mml: 164
	db	$14,$13,$fc,$07,$10,$09,$fc,$04	;Trk C; popipo.mml: 164
	db	$10,$04,$fc,$02,$10,$04,$fc,$02	;Trk C; popipo.mml: 164
	db	$fc,$07,$10,$04,$fc,$02,$10,$09	;Trk C; popipo.mml: 164
	db	$fc,$04,$10,$09,$fc,$04,$10,$09	;Trk C; popipo.mml: 164
	db	$fc,$04,$10,$04,$fc,$02,$10,$05	;Trk C; popipo.mml: 164
	db	$fc,$02,$10,$09,$fc,$04,$10,$12	;Trk C; popipo.mml: 164
	db	$fc,$07,$10,$13,$fc,$07,$14,$13	;Trk C; popipo.mml: 165
	db	$fc,$07,$14,$12,$fc,$07,$19,$13	;Trk C; popipo.mml: 165
	db	$fc,$07,$19,$13,$fc,$07,$15,$13	;Trk C; popipo.mml: 165
	db	$fc,$07,$17,$12,$fc,$07,$10,$13	;Trk C; popipo.mml: 165
	db	$fc,$07,$10,$13,$fc,$07,$14,$12	;Trk C; popipo.mml: 166
	db	$fc,$07,$14,$13,$fc,$07,$10,$09	;Trk C; popipo.mml: 166
	db	$fc,$04,$10,$04,$fc,$02,$10,$05	;Trk C; popipo.mml: 166
	db	$fc,$02,$fc,$06,$10,$05,$fc,$02	;Trk C; popipo.mml: 166
	db	$10,$09,$fc,$04,$fc,$19,$fc,$1a	;Trk C; popipo.mml: 166
	db	$50,$09,$fc,$04,$47,$04,$fc,$02	;Trk C; popipo.mml: 168
	db	$50,$09,$fc,$04,$47,$05,$fc,$02	;Trk C; popipo.mml: 168
	db	$50,$09,$fc,$03,$52,$09,$fc,$04	;Trk C; popipo.mml: 168
	db	$57,$09,$fc,$04,$52,$13,$fc,$07	;Trk C; popipo.mml: 168
	db	$50,$09,$fc,$04,$47,$04,$fc,$02	;Trk C; popipo.mml: 168
	db	$50,$09,$fc,$04,$47,$04,$fc,$02	;Trk C; popipo.mml: 168
	db	$50,$09,$fc,$04,$52,$09,$fc,$04	;Trk C; popipo.mml: 168
	db	$57,$09,$fc,$04,$52,$13,$fc,$07	;Trk C; popipo.mml: 168
	db	$50,$19,$52,$1a,$54,$1a,$55,$1a	;Trk C; popipo.mml: 169
	db	$57,$0c,$55,$07,$54,$26,$52,$0d	;Trk C; popipo.mml: 169
	db	$50,$07,$4b,$13,$52,$0d,$50,$67	;Trk C; popipo.mml: 169

song_000_02_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_02_lp)*2
	dw	song_000_02_lp


song_000_03:	;Trk D
	db	$fe,$8f,$fd,$09,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 59
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 172
	db	$4b,$1a,$4b,$1a,$50,$0d,$4b,$06	;Trk D; popipo.mml: 172
	db	$50,$0d,$4b,$06,$50,$0d,$52,$0d	;Trk D; popipo.mml: 172
	db	$57,$0d,$5b,$1a,$50,$0c,$4b,$07	;Trk D; popipo.mml: 172
	db	$50,$0d,$4b,$06,$50,$0d,$52,$0d	;Trk D; popipo.mml: 172
	db	$57,$0d,$5b,$19,$50,$0d,$4b,$07	;Trk D; popipo.mml: 172
	db	$50,$0d,$4b,$06,$50,$0d,$52,$0d	;Trk D; popipo.mml: 172
	db	$57,$0d,$5b,$19,$50,$0d,$4b,$07	;Trk D; popipo.mml: 172
	db	$50,$0c,$4b,$07,$50,$0d,$52,$0d	;Trk D; popipo.mml: 172
	db	$57,$0c,$5b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 172
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$19,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$19,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$1a	;Trk D; popipo.mml: 173
	db	$4b,$19,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$4b,$1a,$4b,$19	;Trk D; popipo.mml: 173
	db	$4b,$1a,$4b,$1a,$fc,$67,$fc,$66	;Trk D; popipo.mml: 173
	db	$fc,$67,$fc,$07
song_000_03_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_03_lp)*2
	dw	song_000_03_lp


song_000_04:	;Trk E

song_000_04_lp:
	db	$fc,$ff,$ee
	db	bank(song_000_04_lp)*2
	dw	song_000_04_lp

