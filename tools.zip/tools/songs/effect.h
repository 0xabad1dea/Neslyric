dutyenve_table:
	dw	0
	dw	dutyenve_001
	dw	dutyenve_002
	dw	dutyenve_003
	dw	dutyenve_004
	dw	dutyenve_005
	dw	dutyenve_006
dutyenve_lp_table:
	dw	0
	dw	dutyenve_lp_001
	dw	dutyenve_lp_002
	dw	dutyenve_lp_003
	dw	dutyenve_lp_004
	dw	dutyenve_lp_005
	dw	dutyenve_lp_006

dutyenve_001:
dutyenve_lp_001:
	db	$02,$02,$02,$02,$02,$02,$03,$03
	db	$ff
dutyenve_002:
dutyenve_lp_002:
	db	$01,$01,$01,$01,$01,$01,$01,$02
	db	$ff
dutyenve_003:
dutyenve_lp_003:
	db	$01,$01,$01,$01,$01,$01,$01,$01
	db	$02,$02,$02,$03,$02,$02,$02,$02
	db	$ff
dutyenve_004:
dutyenve_lp_004:
	db	$00,$00,$00,$00,$01,$01,$01,$01
	db	$02,$02,$02,$02,$03,$03,$03,$03
	db	$ff
dutyenve_005:
dutyenve_lp_005:
	db	$02,$02,$02,$02,$02,$02,$02,$02
	db	$02,$02,$02,$02,$02,$02,$00,$00
	db	$ff
dutyenve_006:
dutyenve_lp_006:
	db	$01,$01,$01,$01,$01,$01,$01,$01
	db	$01,$01,$01,$01,$01,$01,$00,$00
	db	$ff

softenve_table:
	dw	softenve_000
	dw	softenve_001
	dw	softenve_002
	dw	softenve_003
	dw	softenve_004
	dw	softenve_005
	dw	softenve_006
	dw	softenve_007
	dw	softenve_008
	dw	softenve_009
	dw	softenve_010
	dw	softenve_011
	dw	softenve_012
	dw	softenve_013
softenve_lp_table:
	dw	softenve_lp_000
	dw	softenve_lp_001
	dw	softenve_lp_002
	dw	softenve_lp_003
	dw	softenve_lp_004
	dw	softenve_lp_005
	dw	softenve_lp_006
	dw	softenve_lp_007
	dw	softenve_lp_008
	dw	softenve_lp_009
	dw	softenve_lp_010
	dw	softenve_lp_011
	dw	softenve_lp_012
	dw	softenve_lp_013

softenve_000:
	db	$0a,$09,$08,$07,$06,$05,$04,$03
softenve_lp_000:
	db	$02,$ff
softenve_001:
	db	$0f,$0f,$0e,$0e,$0d,$0d,$0c,$0c
	db	$0b,$0b,$0a,$0a,$09,$09,$08,$08
	db	$07,$07,$06
softenve_lp_001:
	db	$06,$ff
softenve_002:
	db	$0c,$0a,$07,$07,$03,$03,$07,$07
	db	$0a
softenve_lp_002:
	db	$0c,$ff
softenve_003:
	db	$0f,$0c,$0a,$08,$06,$03,$02,$01
softenve_lp_003:
	db	$00,$ff
softenve_004:
	db	$0f,$0e,$0d,$0c,$0b,$0a,$09,$08
	db	$07,$06,$05,$04,$03,$02,$01
softenve_lp_004:
	db	$00,$ff
softenve_005:
	db	$0e,$07,$03,$04,$02,$01,$01,$01
	db	$01,$01,$01
softenve_lp_005:
	db	$00,$ff
softenve_006:
	db	$05,$04,$03,$02,$02,$03
softenve_lp_006:
	db	$04,$ff
softenve_007:
	db	$0f,$0e,$0d,$0c,$0b,$0a,$09,$08
	db	$07,$06,$05,$04,$04,$04,$04
softenve_lp_007:
	db	$04,$ff
softenve_008:
	db	$0e,$0b
softenve_lp_008:
	db	$09,$ff
softenve_009:
	db	$0e,$07,$03,$04,$02,$01,$01,$01
	db	$01,$01,$01
softenve_lp_009:
	db	$00,$ff
softenve_010:
	db	$05,$05,$04,$04,$03,$03,$02,$02
	db	$01,$01,$00,$00,$01,$01,$02,$02
	db	$03,$03,$04,$04,$04,$04,$03,$03
	db	$02,$02,$01,$01,$00,$00,$00,$03
	db	$03,$02,$02,$00,$00,$00,$03,$03
	db	$02,$02,$00,$00
softenve_lp_010:
	db	$02,$ff
softenve_011:
	db	$0a,$08,$06,$04,$04,$06
softenve_lp_011:
	db	$08,$ff
softenve_012:
	db	$03
softenve_lp_012:
	db	$00,$ff
softenve_013:
	db	$0a,$0a,$08,$08,$06,$06,$04,$04
	db	$02,$02,$01,$01,$02,$02,$04,$04
	db	$06,$06,$08,$08,$08,$08,$06,$06
	db	$04,$04,$02,$02,$01,$01,$01,$06
	db	$06,$04,$04,$00,$00,$00,$06,$06
	db	$04,$04,$00,$00
softenve_lp_013:
	db	$04,$ff

pitchenve_table:
	dw	pitchenve_000
	dw	pitchenve_001
	dw	pitchenve_002
	dw	pitchenve_003
	dw	pitchenve_004
	dw	pitchenve_005
	dw	pitchenve_006
	dw	pitchenve_007
pitchenve_lp_table:
	dw	pitchenve_lp_000
	dw	pitchenve_lp_001
	dw	pitchenve_lp_002
	dw	pitchenve_lp_003
	dw	pitchenve_lp_004
	dw	pitchenve_lp_005
	dw	pitchenve_lp_006
	dw	pitchenve_lp_007

pitchenve_000:
pitchenve_lp_000:
	db	$08,$ff
pitchenve_001:
	db	$91
pitchenve_lp_001:
	db	$00,$ff
pitchenve_002:
	db	$04
pitchenve_lp_002:
	db	$01,$ff
pitchenve_003:
	db	$06,$88,$84,$81,$01,$81
pitchenve_lp_003:
	db	$81,$ff
pitchenve_004:
	db	$01
pitchenve_lp_004:
	db	$00,$ff
pitchenve_005:
	db	$84
pitchenve_lp_005:
	db	$82,$ff
pitchenve_006:
	db	$04
pitchenve_lp_006:
	db	$02,$ff
pitchenve_007:
	db	$00
pitchenve_lp_007:
	db	$01,$ff

arpeggio_table:
arpeggio_lp_table:


lfo_data:
	db	$08,$02,$01,$00
	db	$0f,$01,$01,$00
	db	$80,$08,$01,$00
	db	$08,$01,$08,$00
	db	$01,$04,$01,$00

fds_data_table:
fds_effect_select:
fds_4088_data:


n106_channel:
	db	0
n106_wave_init:
n106_wave_table:


vrc7_data_table:


dpcm_data:

; begin DPCM samples

; end DPCM samples


	.include	"popipo.h"
