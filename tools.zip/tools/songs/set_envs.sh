#!/bin/sh
export PPMCK_BASEDIR=..
export NES_INCLUDE=$PPMCK_BASEDIR/nes_include
export PATH=$PATH:$PPMCK_BASEDIR/bin

